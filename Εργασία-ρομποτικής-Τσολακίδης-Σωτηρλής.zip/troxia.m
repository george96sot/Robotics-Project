function [] = troxia()
tf = 3;
a = 50;

[q01, q02, q03, q04] = antistrofi(0, 0, 0, 0, 15);
[q11, q12, q13, q14] = antistrofi(-1, 2, 0, 0, 70);

t1 = (tf/2) - sqrt( a^2*tf^2 - 4*a*(q12-q02) )/2/a;
t2 = (tf/2) - sqrt( a^2*tf^2 - 4*a*(q13-q03) )/(2*a);
t3 = (tf/2) - sqrt( a^2*tf^2 - 4*a*(q14-q04) )/(2*a);

tb = max(t1, t2);
tb = max(tb, t3);
%tb = 0.1*tf;

t = 0;

while t <= tf
    a = 50;
    if t <= tb
        disp('1')
        x = 0 + 1/2*a*t^2;
        v = a*t;
        a = a;
    end
    if t>tb && t<=tf-tb
        disp('2')
        x = 0 + 1/2*a*tb^2 + a*tb*(t-tb);
        v = a*tb;
        a = 0;
    end
    if t>tf-tb
        disp('3')
        x = 0 - 1/2*a*t^2;
        v = -a*t;
        a = a;
    end
    t = t + 1;
    
    disp(x)
    disp(v)
    disp(a)
end

grid;
axis([-4 4 -4 4]);
axis square;
pause(0.01);



end