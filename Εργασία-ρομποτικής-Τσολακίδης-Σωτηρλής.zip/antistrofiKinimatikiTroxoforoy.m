function [vr, vl] = antistrofiKinimatikiTroxoforoy(u, w)
L = 1/2;
R = 1;

vr = (2*u + w*L)/(2*R);
vl = (2*u - w*L)/(2*R);

end