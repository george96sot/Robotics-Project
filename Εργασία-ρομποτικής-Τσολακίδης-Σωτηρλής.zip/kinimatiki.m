function [x, y, z, wx, wy, wz] = kinimatiki(q1, q2, q3, q4)

T10 = [cosd(q1) -sind(q1) 0 0; sind(q1) cosd(q1) 0 0; 0 0 1 0; 0 0 0 1];
T21 = [cosd(q2) -sind(q2) 0 0; 0 0 -1 0; sind(q2) cosd(q2) 0 0; 0 0 0 1];
T32 = [cosd(q3) -sind(q3) 0 1; sind(q3) cosd(q3) 0 0; 0 0 1 0; 0 0 0 1];
T43 = [cosd(q4) -sind(q4) 0 1; sind(q4) cosd(q4) 0 0; 0 0 1 0; 0 0 0 1];
T54 = [1 0 0 1; 0 1 0 0; 0 0 1 0; 0 0 0 1];

T03 = T10*T21*T32;
T04 = T03*T43;
T05 = T04*T54;

x = T05;
y = T04;
z = T03;
wy =q1;
wz=q2+q3+q4;
wx=0;
%R = [T05(1, 1) T05(1, 2) T05(1, 3); T05(2, 1) T05(2, 2) T05(2, 3); T05(3, 1) T05(3, 2) T05(3, 3)];
end