function [q1,q2,q3,q4] = antistrofi(x,y,z,f1,f2)
q1 = atan2(z,x)*180/pi;
%atanf1=0;
R = [cosd(q1) 0 sind(q1); 0 1 0; -sind(q1) 0 cosd(q1)];
P = R*[x; y; z];
l1=1;
l2=1;
l3=1;
if sqrt(x^2 + y^2 +z^2) <= 3
    xx = P(1) - l3*cosd(f2);
    yy = P(2) - l3*sind(f2);
    p = -2*l1*xx;
    q = -2*l1*yy;
    r = xx^2 + yy^2 + l1^2 - l2^2;
    g = atan2( (q/sqrt(p^2 + q^2)), p/sqrt(p^2 + q^2) )*180/pi;
    
    if (-r/sqrt(p^2 + q^2) >= -1) && (-r/sqrt(p^2 + q^2) <= 1)
        q11 = (g + acos(-r/sqrt(p^2 + q^2))*180/pi); %TO ERROR EINAI STO ACOS DEN YPOLOGIZETAI SWSTA!ac
        q12 = (g - acos(-r/sqrt(p^2 + q^2))*180/pi);

        q21 = (atan2(yy - l1*sind(q11)/l2, xx - l1*cosd(q11)/l2)*180/pi) - q11; %%ERROR ATAN2
        q22 = (atan2(yy - l1*sind(q12)/l2, xx - l1*cosd(q12)/l2)*180/pi) - q12; %%ERROR ATAN2
        q31 = f2 - abs(q21 + q11);

        [a,b,c,wx,wy,wz]=kinimatiki(q1,q11,q21,q31);
    
        if (fix(y*10000) == fix(a(3,4)*10000) && fix(x*10000) == fix(a(1,4)*10000) && fix(z*10000) == fix(a(2,4)*10000))% && z==a(2,4)) %%EDW TA X,Y,Z EPISTREFOUN PINAKA, ARA EMEIS THELOUME APO TON PINAKA TO X,Y,Z TIS ANTISTOIXES THESEIS
            disp('hi')
            q2=q11;
            q3=q21;
            q4=q31;
        else
            q2=q12;
            q3=q22;
            q4=q31;
        end
    else
        disp('Den mporw na koitaw pros ta ekei!!!!!')
        q2=0;
        q3=0;
        q4=0;
    end
else
    disp ('Den mporw na paw ekei!!!!')
    quit cancel;
end

end