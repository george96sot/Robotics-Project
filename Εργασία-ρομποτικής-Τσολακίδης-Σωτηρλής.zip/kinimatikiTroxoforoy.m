function [vx, vy, vq] = kinimatikiTroxoforoy(vr, vl, q)
r = 0.2;

R = [cosd(q) sind(q) 0; sind(q) -cosd(q) 0; 0 0 1];
V = [(r*vr/2) + (r*vl/2); 0; (r*vl/2)-(r*vr/2)];
Q = R*V;

vx = Q(1);
vy = Q(2);
vq = Q(3)*180/pi;

end